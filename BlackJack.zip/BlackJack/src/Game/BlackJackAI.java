package Game;
import java.util.Random;
import java.util.Vector;

public abstract class BlackJackAI {
	
	public Vector<Integer> hand;
	public void hitorstay(Vector<Integer> deck,Random r) {
	};
}
